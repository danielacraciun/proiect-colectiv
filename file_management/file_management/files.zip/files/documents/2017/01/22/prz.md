<!-- $theme: gaia -->

DNS Tunneling
=============
###### or Another Way to Get Free Internet in Airports/Cafes

---
#
##### Many networks have *restricted internet access*
#
Wireless access points in hotels and airports
Censored Internet access in some countries


##### Question: how can one get full internet acess?
##### Idea: leverage one of the unfiltered protocols

---
### DNS (Domain Name Server)
- Almost never filtered
- Cannot reply with wrong results because of cache
- Not designed for tunnelling data (has limitations)

# ![](http://open.lib.umn.edu/informationsystems/wp-content/uploads/sites/4/2015/03/f94d2529652d348ccc462c652b0fcb32.jpg)

---
# ![](http://www.admin-magazine.com/var/ezflow_site/storage/images/media/images/recon-t01/43652-1-eng-US/recon-T01_reference.jpg)
For DNS Tunneling are used NS and A records 
**A record**: maps hostname to 32-bit IPv4 address
**NS record**: maps subdomain to a set of name servers

---

## How internet access is blocked
# ![](img2.png)

---

## How does DNS tunneling work?

---

## What is needed for DNS tunneling
- A DNS server that you can configure (enough permissions to allow you control over port 53)
- Another server, one not running DNS
- Some software to facilitate it
- Client machine

---

#### Existing implementations of DNS tunneling
- Iodine
- OzymanDNS

###### Not supported anymore:
- dns2tcp
- NSTX 

---
## What is iodine?
---
### Using iodine for DNS tunneling
# ![](http://2we26u4fam7n16rz3a44uhbe1bq2.wpengine.netdna-cdn.com/wp-content/uploads/maintainingaccess/DNS-Tunneling.png)
---
##### CLIENT: 
- uses iodine to encapsulate Ipv4 traffic into DNS traffic and sends the entire traffic to a subdomain. 

##### SERVER:
-  After the traffic has reached our subdomain, iodine running on our server converts it to normal traffic -> forward to queried domain
- iodine server gets a response back -> encapsulates the normal traffic into DNS -> sends it through the tunnel. 

The DNS traffic is allowed by the firewall and is able to reach the client.

---

### Downsides of DNS tunneling
- a bit more complicated setup 
- the speed is very slow, as all data is sent inside DNS requests, which limits the amount in single packet and requires more packets to be sent.

---

### DNS tunneling, step by step
- check if DNS traffic is allowed. Try pinging any domain. If you get an IP-address in the reply section, then it means that DNS packets are allowed, because the query went to the DNS server and it returned back the IP-Address of the domain.
- Add 2 DNS entries: an "A" and a "NS" record
"33.33.33.33" - IP address of your tunnel server
"hostname.com" is the domain you control
```
tunnel1 IN A 33.33.33.33
tunnelme IN NS tunnel1.hostname.com
```
---
- Configure iodine on your server, then on the client
##### Server
``` iodined -f -c -P secretPassword22 192.168.99.1 tunnelme.hostname.com```

##### Client
``` iodine -f -r 46.101.240.178 tunnelme.hostname.com```
- Done!

---

# The end!

